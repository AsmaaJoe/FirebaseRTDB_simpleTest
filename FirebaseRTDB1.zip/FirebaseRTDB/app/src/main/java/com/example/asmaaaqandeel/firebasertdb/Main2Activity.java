package com.example.asmaaaqandeel.firebasertdb;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Main2Activity extends AppCompatActivity {

    private static final String TAG = "QuestionView";

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("qustion");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        final TextView question_body = (TextView) findViewById(R.id.question_body);
        final RadioButton first_option = (RadioButton) findViewById(R.id.first_option);
        final RadioButton second_option = (RadioButton) findViewById(R.id.second_option);
        final RadioButton third_option = (RadioButton) findViewById(R.id.third_option);

        // Read from the database
        // final TextView mQuestion = findViewById(R.id.question_body);

try {
    myRef.addValueEventListener(new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
            // This method is called once with the initial value and again
            // whenever data at this location is updated.
            question value = dataSnapshot.getValue(question.class);
            Log.d(TAG, "Value is: " + value);
            //set the question view and show the question
            try {
                question_body.setText(value.getQuestionBody());
                first_option.setText(value.getFirstOption());
                second_option.setText(value.getSecondOption());
                third_option.setText(value.getThirdOption());

            }catch (Exception e){
                Toast.makeText(Main2Activity.this, e.toString() + " can't read", Toast.LENGTH_LONG).show();
            }

        }

        @Override
        public void onCancelled(DatabaseError error) {
            // Failed to read value
            Log.w(TAG, "Failed to read value.", error.toException());
        }
    });
}
        catch (Exception e){
        Toast.makeText(Main2Activity.this, e.toString() + "  2", Toast.LENGTH_LONG).show();
    }
    }

    public void onRadioButtonClicked(View view) {



    }
}
