package com.example.asmaaaqandeel.firebasertdb;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by asmaaaqandeel on 24/06/18.
 */
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

//@SuppressLint("Registered")
public class question extends AppCompatActivity{

    private String mQuestionBody ;
    private String mFirstOption ;
    private String mSecondOption ;
    private String mThirdOption ;

    public question(){}

    public question(String questionbody,
                    String firstoption,
                    String secondoption,
                    String thirdoption)
    {
        mQuestionBody = questionbody;
        mFirstOption  = firstoption;
        mSecondOption = secondoption;
        mThirdOption  = thirdoption;
    }


    public String getQuestionBody()
    {return mQuestionBody;}
    public void setQuestionBody(String questionBody)
    {mQuestionBody = questionBody;}

    public String getFirstOption()
    {return mFirstOption;}
    public void setFirstOption(String firstOption)
    {mFirstOption = firstOption;}

    public String getSecondOption()
    {return mSecondOption;}
    public void setSecondOption(String secondOption)
    {mSecondOption = secondOption; }

    public String getThirdOption()
    {return mThirdOption;}
    public void setThirdOption(String thirdOption)
    {mThirdOption = thirdOption; }
}
